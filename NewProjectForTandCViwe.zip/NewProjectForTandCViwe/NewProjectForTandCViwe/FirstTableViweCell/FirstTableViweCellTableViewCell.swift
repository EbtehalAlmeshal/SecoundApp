//
//  FirstTableViweCellTableViewCell.swift
//  NewProjectForTandCViwe
//
//  Created by ابتهال عبدالعزيز on 19/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class FirstTableViweCellTableViewCell: UITableViewCell {

    @IBOutlet weak var nemaLabel: UILabel!
    @IBOutlet weak var jobLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    func updateinformation(person : PersonClass) {
        self.nemaLabel.text = "Name : " +  person.name
        self.jobLabel.text = "Job  : " +  person.job
        self.ageLabel.text = "Age : " + String(person.ege)
        if let address = person.address {
            self.addressLabel.text = "Address : " + address
        }else{
            self.addressLabel.text = ""
        }
    }
    
}
