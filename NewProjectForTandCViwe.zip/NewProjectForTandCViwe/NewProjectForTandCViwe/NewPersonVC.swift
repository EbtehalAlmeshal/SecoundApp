//
//  NewPersonVC.swift
//  NewProjectForTandCViwe
//
//  Created by Ebtehal 🕸 on 28/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class  NewPersonVC :  UIViewController{
    // هنا سويت متغير من نوع دليقيت
    var delegate : personDelegate!
    
    @IBOutlet weak  var nameTextField :UITextField!
    @IBOutlet weak  var jobTextField :UITextField!
    @IBOutlet weak  var ageTextField :UITextField! 
    @IBOutlet weak  var addressTextField :UITextField!
    
    @IBAction func saveButton (sender : UIBarButtonItem){
        
        // ارسال اشاره عند الضغط ع الحفظ
    //    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "FN"), object: nil, userInfo:nil)
       //هنا الريتيرن يوقف الاوامر اللي بعدها
        
        if let ageNumber = Int(ageTextField.text!){
            let finalAddress : String? = addressTextField.text! == "" ? nil : addressTextField.text!
           let newperson = PersonClass(name: nameTextField.text!, job: jobTextField.text!, age:ageNumber, address: finalAddress)
            
            delegate.newPerson(new: newperson)
            // هنا يرجعني لصفحة اللي قبلها
            navigationController?.popViewController(animated: true)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(NewPersonVC.keywordWillShow(notification:)),
                                               name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(NewPersonVC.keywordWillhide),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
  
    @IBOutlet weak var button: NSLayoutConstraint!
    
  @objc  func keywordWillShow ( notification :  Notification){
    if let keywordFrame : NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue{
        let rectangle = keywordFrame.cgRectValue
        let height = rectangle.height
        button.constant = height
        // يحدث الي الكيبورد بعد التعديل
        view.layoutIfNeeded()
        print(height)
    }
        print("kw will show")
    }
  @objc func keywordWillhide (){
    // هنا ارجعه للوضع الاصلي
    button.constant = 0
      view.layoutIfNeeded()
    print(" KW will hide" )
        
    }
}

