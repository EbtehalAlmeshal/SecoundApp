//
//  ViewController.swift
//  NewProjectForTandCViwe
//
//  Created by ابتهال عبدالعزيز on 19/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit
// اذا سويت ديليقت لازم اسوي له وراثه هنا
class ViewController: UIViewController , UITableViewDataSource , UITableViewDelegate , personDelegate {
   
   // هنا اقدر اضيف موظف جديد للجدول 
    func newPerson(new: PersonClass) {
        print("hiii")
        peopel.append(new)
        TableViwe.reloadData()
    }
    
   
     var peopel :[PersonClass] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // هنا اضفت عشان اقدر اسوي رفريش
        self.TableViwe.addSubview(self.refreshControl)
        
        TableViwe.register(UINib(nibName: "FirstTableViweCellTableViewCell", bundle: nil), forCellReuseIdentifier: "FirstCell")
    // استقبل الاشاره
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.gotTheNotification), name: NSNotification.Name(rawValue: "FN"), object: nil)
    }
    
    @objc func gotTheNotification () {
        self.view.backgroundColor = UIColor.gray
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peopel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Cell = TableViwe.dequeueReusableCell(withIdentifier:"FirstCell")as! FirstTableViweCellTableViewCell
        Cell.updateinformation(person: peopel[indexPath.row])
        return Cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80 
    }
    // هنا يحذف لي رو كامل من الجدول
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            peopel.remove(at: indexPath.row)
            TableViwe.deleteRows(at:[indexPath], with: .fade)
        }
    }
    
    // هنا عرفته ليزي عشان ما ينفذه الا وقت الحاجه و برضو فايده الاد تارقت عشان تتنفذ الفنكشن
    lazy var refreshControl : UIRefreshControl! = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector (ViewController.handleRefresh), for: UIControl.Event.valueChanged)
        refreshControl.tintColor = UIColor.blue
        return refreshControl
    }()
    @ objc func handleRefresh (){
        TableViwe.reloadData()
        refreshControl.endRefreshing()
        
    }
    @IBOutlet weak var TableViwe: UITableView!
    
    
    // ينفذ نفسه وقت الانتقال
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let next = segue.destination as? NewPersonVC{
            next.delegate = self
        }
    }
    
    
}

protocol personDelegate {
    func newPerson (new : PersonClass )
}

