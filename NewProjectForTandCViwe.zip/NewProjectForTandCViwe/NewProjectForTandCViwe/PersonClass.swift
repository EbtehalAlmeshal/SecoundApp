//
//  PersonClass.swift
//  NewProjectForTandCViwe
//
//  Created by Ebtehal 🕸 on 28/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import Foundation

class PersonClass{
  var  name : String
    var job : String
    var ege : Int
    var address : String?
    
    init(name : String , job : String , age : Int , address  : String?  ) {
        self.name = name
        self.job = job
        self.ege = age
        self.address = address 
    }
}

